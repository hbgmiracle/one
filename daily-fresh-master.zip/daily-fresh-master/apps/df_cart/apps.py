from django.apps import AppConfig


class DfCartConfig(AppConfig):
    name = 'df_cart'
    verbose_name = "购物车"