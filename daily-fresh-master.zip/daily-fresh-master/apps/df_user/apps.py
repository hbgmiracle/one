from django.apps import AppConfig


class DfUserConfig(AppConfig):
    name = 'df_user'
    verbose_name = "用户"