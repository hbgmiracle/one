from django.apps import AppConfig


class DfOrderConfig(AppConfig):
    name = 'df_order'
    verbose_name = "订单"
