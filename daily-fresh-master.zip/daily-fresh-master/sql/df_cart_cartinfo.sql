INSERT INTO "df_cart_cartinfo" VALUES ('61', '9', '33', '1');
INSERT INTO "df_cart_cartinfo" VALUES ('63', '14', '33', '4');
INSERT INTO "df_cart_cartinfo" VALUES ('66', '12', '32', '2');
INSERT INTO "df_cart_cartinfo" VALUES ('67', '15', '39', '1');
