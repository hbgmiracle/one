INSERT INTO "df_user_userinfo" VALUES ('32', '111111', '3d4f2bf07dc1be38b20cd6e46949a1071f9d0e3d', '123123@163.com', '散人', '河南理工大学南校区', '13323232332', '477100');
INSERT INTO "df_user_userinfo" VALUES ('33', 'sanren', '4569416a6a60a85332f52e25b096bec0be49060a', '123123@163.com', '散人', '112', '112', '112');
INSERT INTO "df_user_userinfo" VALUES ('34', 'root2', '7b21848ac9af35be0ddb2d6b9fc3851934db8420', 'weilanhanf@163.com', '', '', '', '');
INSERT INTO "df_user_userinfo" VALUES ('35', '11111', '7b21848ac9af35be0ddb2d6b9fc3851934db8420', 'weilanhanf@163.com', '', '', '', '');
INSERT INTO "df_user_userinfo" VALUES ('36', '22222', '1a9b9508b6003b68ddfe03a9c8cbc4bd4388339b', 'weilaanf@163.com', '', '', '', '');
INSERT INTO "df_user_userinfo" VALUES ('37', '33333', '403d9917c3e950798601addf7ba82cd3c83f344b', 'weilanhanf@163.com', '', '', '', '');
INSERT INTO "df_user_userinfo" VALUES ('38', 'login', '2736fab291f04e69b62d490c3c09361f5b82461a', '111111@qq.com', '', '', '', '');
INSERT INTO "df_user_userinfo" VALUES ('39', 'asdfg', 'f1b699cc9af3eeb98e5de244ca7802ae38e77bae', 'sadfasdfasd@qq.com', '', '', '', '');
