INSERT INTO "df_goods_typeinfo" VALUES ('1', '0', '新鲜水果');
INSERT INTO "df_goods_typeinfo" VALUES ('2', '0', '海鲜水产');
INSERT INTO "df_goods_typeinfo" VALUES ('3', '0', '猪羊牛肉');
INSERT INTO "df_goods_typeinfo" VALUES ('4', '0', '禽类蛋品');
INSERT INTO "df_goods_typeinfo" VALUES ('5', '0', '新鲜蔬菜');
INSERT INTO "df_goods_typeinfo" VALUES ('6', '0', '速冻食品');
