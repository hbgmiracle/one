INSERT INTO "df_order_orderdetailinfo" VALUES ('1', '1', '8', '2018122009332333', '26');
INSERT INTO "df_order_orderdetailinfo" VALUES ('2', '1', '14', '2018122009345533', '22');
INSERT INTO "df_order_orderdetailinfo" VALUES ('3', '1', '13', '2018122009352733', '20');
INSERT INTO "df_order_orderdetailinfo" VALUES ('4', '9', '12', '2018122009415333', '45');
INSERT INTO "df_order_orderdetailinfo" VALUES ('5', '3', '15', '2019042720141632', '20');
INSERT INTO "df_order_orderdetailinfo" VALUES ('6', '2', '18', '2019050121492832', '12');
INSERT INTO "df_order_orderdetailinfo" VALUES ('7', '3', '17', '2019050121492832', '89');
